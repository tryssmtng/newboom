from flask import Flask, Response, render_template, request
from faker import Faker
import time
import random
import json
import requests
import logging
import uuid

app = Flask(__name__)
fake = Faker('en_IN')

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# In-memory cache for form type
form_type_cache = {}

# Proxy configuration
proxy_user = "sptpeyn8ci"
proxy_pass = "x3xpfNh9n+aQ1XNx2w"
http_proxy = f"http://{proxy_user}:{proxy_pass}@in.smartproxy.com:10000"
socks5_proxy = f"socks5://{proxy_user}:{proxy_pass}@gate.smartproxy.com:7000"

proxies = {
    "http": http_proxy,
    "https": http_proxy,
    "socks5": socks5_proxy,
}

# Rate limiting configuration
MAX_REQUESTS_PER_MINUTE = 500  # Maximum number of requests per minute
MIN_DELAY = 60 / MAX_REQUESTS_PER_MINUTE  # Minimum delay between requests in seconds

state_city_zip_dict = {
    "Andhra Pradesh": {"city": "Visakhapatnam", "zip": "530"},
    "Arunachal Pradesh": {"city": "Itanagar", "zip": "791"},
    "Assam": {"city": "Dispur", "zip": "781"},
    "Bihar": {"city": "Patna", "zip": "800"},
    "Chhattisgarh": {"city": "Raipur", "zip": "492"},
    "Goa": {"city": "Panaji", "zip": "403"},
    "Gujarat": {"city": "Gandhinagar", "zip": "382"},
    "Haryana": {"city": "Chandigarh", "zip": "160"},
    "Himachal Pradesh": {"city": "Shimla", "zip": "171"},
    "Jharkhand": {"city": "Ranchi", "zip": "834"},
    "Karnataka": {"city": "Bangalore", "zip": "560"},
    "Kerala": {"city": "Thiruvananthapuram", "zip": "695"},
    "Madhya Pradesh": {"city": "Bhopal", "zip": "462"},
    "Maharashtra": {"city": "Mumbai", "zip": "400"},
    "Manipur": {"city": "Imphal", "zip": "795"},
    "Meghalaya": {"city": "Shillong", "zip": "793"},
    "Mizoram": {"city": "Aizawl", "zip": "796"},
    "Nagaland": {"city": "Kohima", "zip": "797"},
    "Odisha": {"city": "Bhubaneswar", "zip": "751"},
    "Punjab": {"city": "Chandigarh", "zip": "160"},
    "Rajasthan": {"city": "Jaipur", "zip": "302"},
    "Sikkim": {"city": "Gangtok", "zip": "737"},
    "Tamil Nadu": {"city": "Chennai", "zip": "600"},
    "Telangana": {"city": "Hyderabad", "zip": "500"},
    "Tripura": {"city": "Agartala", "zip": "799"},
    "Uttar Pradesh": {"city": "Lucknow", "zip": "226"},
    "Uttarakhand": {"city": "Dehradun", "zip": "248"},
    "West Bengal": {"city": "Kolkata", "zip": "700"},
    "Chandigarh": {"city": "Chandigarh", "zip": "160"},
    "Delhi": {"city": "New Delhi", "zip": "110"},
    "Lakshadweep": {"city": "Kavaratti", "zip": "682"},
    "Puducherry": {"city": "Puducherry", "zip": "605"},
}

state_abbreviation_dict = {
    "Andhra Pradesh": "AP",
    "Arunachal Pradesh": "AR",
    "Assam": "AS",
    "Bihar": "BR",
    "Chhattisgarh": "CG",
    "Goa": "GA",
    "Gujarat": "GJ",
    "Haryana": "HR",
    "Himachal Pradesh": "HP",
    "Jharkhand": "JH",
    "Karnataka": "KA",
    "Kerala": "KL",
    "Madhya Pradesh": "MP",
    "Maharashtra": "MH",
    "Manipur": "MN",
    "Meghalaya": "ML",
    "Mizoram": "MZ",
    "Nagaland": "NL",
    "Odisha": "OD",
    "Punjab": "PB",
    "Rajasthan": "RJ",
    "Sikkim": "SK",
    "Tamil Nadu": "TN",
    "Telangana": "TS",
    "Tripura": "TR",
    "Uttar Pradesh": "UP",
    "Uttarakhand": "UK",
    "West Bengal": "WB",
    "Chandigarh": "CH",
    "Delhi": "DL",
    "Lakshadweep": "LD",
    "Puducherry": "PY",
    "Ladakh": "LA",
}

def extract_product_details(product_url, use_socks5=True):
    selected_proxies = {"http": proxies["http"], "https": proxies["http"]}
    if use_socks5:
        selected_proxies = {"http": proxies["socks5"], "https": proxies["socks5"]}

    try:
        response = requests.get(product_url, allow_redirects=True, timeout=10, proxies=selected_proxies)
        response.raise_for_status()
    except requests.exceptions.RequestException as e:
        raise Exception(f"Failed to fetch the product page: {e}")

    page_content = response.text
    product_details = {"form_type": None}

    if 'var EASYSELL_CONFIG =' in page_content:
        logger.info("EASYSELL COD FORM detected")
        product_details["form_type"] = "EASY_SELL_COD"
    elif 'var _RSI_COD_FORM_SETTINGS ' in page_content:
        logger.info("RSI COD FORM detected")
        product_details["form_type"] = "RSI_COD_FORM"
    else:
        logger.info("No recognized COD form detected")

    return product_details

def generate_secondary_address():
    # Simulate a secondary address component
    apartment_number = fake.random_int(min=1, max=20)
    apartment_letter = fake.random_element(elements=('A', 'B', 'C', 'D'))
    return f"Apartment {apartment_number}{apartment_letter}, {fake.building_number()}"

def generate_consistent_fake_data(state, city, zip_prefix):
    # Generate fake data using pre-selected consistent state, city, and zip code
    first_name = fake.first_name()
    last_name = fake.last_name()
    phone = str(fake.random_int(min=7000000000, max=9999999999))
    address = fake.street_address().replace('\n', ', ')
    secondary_address = generate_secondary_address()
    zip_code = zip_prefix + str(fake.random_int(min=100, max=999))
    province = state_abbreviation_dict[state]

    # Create a dictionary of generated data to ensure consistency
    generated_data = {
        "abandoned_order_id": str(uuid.uuid4()),
        "first_name": first_name,
        "last_name": last_name,
        "phone": phone,
        "address": address,
        "address2": secondary_address,
        "province_country_field": province,
        "city": city,
        "additionals_text_input_zip_code": zip_code,
    }

    return generated_data

def replace_placeholders(data, generated_data):
    for placeholder, value in generated_data.items():
        data = data.replace(f"{{{{{placeholder}}}}}", value)
    return data

def send_request(product_url, data, headers, pacing, use_socks5=True):
    delay_map = {1: (1, 5), 2: (5, 10), 3: (10, 20)}
    min_delay, max_delay = delay_map[pacing]

    def perform_request(data):
        selected_proxies = {"http": proxies["http"], "https": proxies["http"]}
        if use_socks5:
            selected_proxies = {"http": proxies["socks5"], "https": proxies["socks5"]}

        try:
            response = requests.post(url, json=data, headers=headers, proxies=selected_proxies)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Request Error occurred: {str(e)}")
            return None

    try:
        if product_url not in form_type_cache:
            product_details = extract_product_details(product_url, use_socks5)
            form_type_cache[product_url] = product_details["form_type"]
        else:
            product_details = {"form_type": form_type_cache[product_url]}

        if product_details["form_type"] is None:
            logger.error("No COD Form Detected. Order Processing Stopped")
            return "No COD Form Detected. Order Processing Stopped"

        host = product_url.split('/')[2]

        if product_details["form_type"] == "RSI_COD_FORM":
            url = f"https://{host}/apps/rsi-cod-form-do-not-change/create-order"
            headers["Host"] = host
        elif product_details["form_type"] == "EASY_SELL_COD":
            url = "https://load.tyslo.com/order/new"
            headers["Host"] = "load.tyslo.com"

        attempt = 0
        max_retries = 3
        while attempt < max_retries:
            data_dict = json.loads(data)
            form_data = data_dict.get('formData', [])

            selected_state, location = random.choice(list(state_city_zip_dict.items()))
            selected_city = location["city"]
            selected_zip_prefix = location["zip"]

            for item in form_data:
                generated_data = generate_consistent_fake_data(selected_state, selected_city, selected_zip_prefix)
                item['value'] = replace_placeholders(item['value'], generated_data)

            res = perform_request(data_dict)

            if res:
                if 'customRsiErrorMessage' in res and res['customRsiErrorMessage'] == "blocked":
                    logger.warning(f"Attempt {attempt + 1}: Request blocked, retrying with new data.")
                    attempt += 1
                    time.sleep(random.uniform(min_delay, max_delay))
                else:
                    if res.get('success') and 'data' in res and 'order' in res['data']:
                        order = res['data']['order']
                        order_details = {
                            "Order Number": order.get("order_number", ""),
                            "Full name": f"{order.get('billing_address', {}).get('first_name', '')} {order.get('billing_address', {}).get('last_name', '')}",
                            "Phone number": order.get('billing_address', {}).get('phone', ''),
                            "Address": order.get('billing_address', {}).get('address1', ''),
                            "State": order.get('billing_address', {}).get('province', ''),
                            "City": order.get('billing_address', {}).get('city', ''),
                            "zip_code": order.get('billing_address', {}).get('zip', ''),
                            "Order Status URL": order.get("order_status_url", "")
                        }
                        event_message = f"Order Details: {order_details}\n\n"
                        print(event_message)
                    elif 'order' in res:
                        order = res['order']
                        order_details = {
                            "Order Number": order.get("order_number", ""),
                            "Full name": f"{order.get('billing_address', {}).get('first_name', '')} {order.get('billing_address', {}).get('last_name', '')}",
                            "Phone number": order.get('billing_address', {}).get('phone', ''),
                            "Address": order.get('billing_address', {}).get('address1', ''),
                            "State": order.get('billing_address', {}).get('province', ''),
                            "City": order.get('billing_address', {}).get('city', ''),
                            "zip_code": order.get('billing_address', {}).get('zip', ''),
                            "Order Status URL": order.get("order_status_url", "")
                        }
                        event_message = f"Order Details: {order_details}\n\n"
                        print(event_message)
                    else:
                        event_message = f"Request completed with no order details. Response: {res}\n\n"
                    logger.info(event_message)
                    time.sleep(max(MIN_DELAY, random.uniform(min_delay, max_delay)))
                    return event_message
            else:
                event_message = f"Request failed after {attempt + 1} attempts.\n\n"
                break

        return event_message

    except Exception as e:
        error_message = f"Unexpected Error occurred: {str(e)}\n\n"
        logger.error(error_message)
        return error_message

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/process_orders', methods=['GET'])
def process_orders():
    product_url = request.args.get('product_urls')
    total_requests = int(request.args.get('total_requests'))
    pacing_choice = int(request.args.get('pacing_choice'))
    data = request.args.get('data')
    headers_raw = request.args.get('headers')
    use_socks5 = request.args.get('use_socks5', 'false').lower() == 'true'

    headers = dict(line.split(": ", 1) for line in headers_raw.split("\n") if line)

    def event_stream():
        for _ in range(total_requests):
            result = send_request(product_url, data, headers, pacing_choice, use_socks5)
            yield f"data: {result}\n\n"

        yield "data: Completed all requests\n\n"

    return Response(event_stream(), content_type='text/event-stream')

if __name__ == '__main__':
    app.run(debug=True, port=5001)
